from setuptools import setup  

setup( 
      name = 'python_source_distribution_packaging', 
      version = '1.0.0', 
      py_modules = ['addition'], 
      author ='Suraj Kande', 
      #author_email = 'surajkande1298@gmail.com', 
      description = 'a simple program to add two numbers', 
      keywords='adds two numbers', 
) 
